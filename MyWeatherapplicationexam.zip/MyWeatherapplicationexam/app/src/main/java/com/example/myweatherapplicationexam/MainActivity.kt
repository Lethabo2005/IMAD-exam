package com.example.myweatherapplicationexam

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import kotlin.system.exitProcess

class MainActivity : AppCompatActivity() {

    private lateinit var startButton: Button
    private lateinit var exitButton: Button

    private val weatherData = mutableListOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

       val startButton: Button = findViewById(R.id.startButton)
       val exitButton: Button = findViewById(R.id.exitButton)

        startButton.setOnClickListener {
            startActivity(Intent(this, MainActivity2::class.java))
        }

        exitButton.setOnClickListener {
            finish()
        } }
}

