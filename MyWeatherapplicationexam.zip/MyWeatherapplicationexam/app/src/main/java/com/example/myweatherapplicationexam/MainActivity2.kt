package com.example.myweatherapplicationexam

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity2 : AppCompatActivity() {

    private lateinit var checkWeatherButton: Button
    private lateinit var returnButton: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        checkWeatherButton = findViewById(R.id.checkWeatherButton)
        returnButton = findViewById(R.id.returnButton)

        checkWeatherButton.setOnClickListener {

        }
        returnButton.setOnClickListener {

        }
    }
}